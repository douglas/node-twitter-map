/* Begin all files as hidden visibility */
#pragma GCC visibility push(hidden)
